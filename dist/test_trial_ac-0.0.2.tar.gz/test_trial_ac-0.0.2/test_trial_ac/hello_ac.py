def greet():
    print("Good Luck Everyone!")

def check_palindrome(s):
    print(s==s[::-1])